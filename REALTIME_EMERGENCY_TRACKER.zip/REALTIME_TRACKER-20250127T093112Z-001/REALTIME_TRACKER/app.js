const express = require("express");
const app = express();
const path = require("path");
const http = require("http");
const socketio = require("socket.io");
const bodyParser = require("body-parser");
const session = require("express-session");
const mysql = require("mysql2");
const bcrypt = require('bcrypt');

const server = http.createServer(app);
const io = socketio(server);

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // Add your MySQL password if required
    database: 'safe_zone'
});

db.connect((err) => {
    if (err) throw err;
    console.log("Connected to the database.");
});

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'secret-key', // Use a strong, unique secret key
    resave: false,
    saveUninitialized: true,
}));

// Middleware to check if server user is authenticated
function isServerAuthenticated(req, res, next) {
    if (req.session.serverUserId) {
        return next();
    }
    res.redirect('/server_login');
}

// Middleware to check if client user is authenticated
function isAuthenticated(req, res, next) {
    if (req.session.userId) {
        return next();
    }
    res.redirect('/emergency_login');
}

// Check if there are any server users already in the database
function checkFirstTimeSetup(req, res, next) {
    const query = 'SELECT * FROM server_users';
    db.query(query, (err, results) => {
        if (err) throw err;
        if (results.length > 0) {
            return next();
        } else {
            res.redirect('/server_signup');
        }
    });
}

// Redirect root URL to server login if not logged in
app.get("/", isServerAuthenticated, (req, res) => {
    res.render("index");
});

// Server User Routes
app.get("/server_login", checkFirstTimeSetup, (req, res) => {
    res.render("server_login");
});

app.post("/server_login", (req, res) => {
    const { email, password } = req.body;
    const query = 'SELECT * FROM server_users WHERE email = ?';

    db.query(query, [email], (err, results) => {
        if (err) {
            console.error("Database query error:", err);
            return res.render("server_login", { error: "An error occurred. Please try again." });
        }
        if (results.length > 0) {
            const user = results[0];

            // Compare the hashed password
            bcrypt.compare(password, user.password, (err, isMatch) => {
                if (err) {
                    console.error("Error comparing passwords:", err);
                    return res.render("server_login", { error: "An error occurred. Please try again." });
                }
                if (isMatch) {
                    req.session.serverUserId = user.id;
                    console.log("Server user logged in successfully:", user.id);
                    res.redirect("/");
                } else {
                    console.log("Invalid password for server user:", email);
                    res.render("server_login", { error: "Invalid password. Please try again." });
                }
            });
        } else {
            console.log("Server user not found:", email);
            res.render("server_login", { error: "Invalid email. Please try again." });
        }
    });
});

app.get("/server_signup", (req, res) => {
    res.render("server_signup");
});

app.post("/server_signup", (req, res) => {
    const { email, password, name } = req.body;

    // Hash the password
    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) throw err;

        const query = 'INSERT INTO server_users (email, password, name) VALUES (?, ?, ?)';
        db.query(query, [email, hashedPassword, name], (err, result) => {
            if (err) throw err;
            req.session.serverUserId = result.insertId;
            res.redirect("/");
        });
    });
});

app.get("/logout", (req, res) => {
    req.session.destroy((err) => {
        if (err) throw err;
        res.redirect("/server_login");
    });
});

// Client User Routes
app.get("/emergency", (req, res) => {
    res.redirect("/emergency_login");
});

app.get("/emergency_login", (req, res) => {
    res.render("emergency_login");
});

app.post("/emergency_login", (req, res) => {
    const { email, password } = req.body;
    const query = 'SELECT * FROM client_users WHERE email = ?';

    db.query(query, [email], (err, results) => {
        if (err) {
            console.error("Database query error:", err);
            return res.render("emergency_login", { error: "An error occurred. Please try again." });
        }
        if (results.length > 0) {
            const user = results[0];

            // Compare the hashed password
            bcrypt.compare(password, user.password, (err, isMatch) => {
                if (err) {
                    console.error("Error comparing passwords:", err);
                    return res.render("emergency_login", { error: "An error occurred. Please try again." });
                }
                if (isMatch) {
                    req.session.userId = user.id;
                    console.log("Client user logged in successfully:", user.id);
                    res.redirect("/emergency_dashboard");
                } else {
                    console.log("Invalid password for client user:", email);
                    res.render("emergency_login", { error: "Invalid password. Please try again." });
                }
            });
        } else {
            console.log("Client user not found:", email);
            res.render("emergency_login", { error: "Invalid email. Please try again." });
        }
    });
});

app.get("/emergency_signup", (req, res) => {
    res.render("emergency_signup");
});

app.post("/emergency_signup", (req, res) => {
    const { email, password, name } = req.body;

    // Hash the password
    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) throw err;

        const query = 'INSERT INTO client_users (email, password, name) VALUES (?, ?, ?)';
        db.query(query, [email, hashedPassword, name], (err, result) => {
            if (err) throw err;
            req.session.userId = result.insertId;
            res.redirect("/emergency_dashboard");
        });
    });
});

app.get("/emergency_dashboard", isAuthenticated, (req, res) => {
    res.render("emergency_dashboard", { userId: req.session.userId });
});

// Emergency User Logout Route
app.get("/emergency_logout", (req, res) => {
    req.session.destroy((err) => {
        if (err) throw err;
        res.redirect("/emergency_login");
    });
});

// Endpoint to view request logs
app.get("/logs/view", isServerAuthenticated, (req, res) => {
    const query = 'SELECT * FROM emergency_signals ORDER BY timestamp DESC';
    db.query(query, (err, results) => {
        if (err) throw err;
        let html = '<h1>Emergency Request Logs</h1>';
        html += '<table border="1"><tr><th>User ID</th><th>Type</th><th>Location</th><th>Timestamp</th><th>IP Address</th><th>Count</th><th>Time Since Last Request</th></tr>';

        results.forEach(log => {
            const timeSinceLastRequest = `${Math.round((new Date() - new Date(log.timestamp)) / 1000)} seconds ago`;
            html += `<tr>
                        <td>${log.user_id}</td>
                        <td>${log.type}</td>
                        <td>${log.latitude}, ${log.longitude}</td>
                        <td>${log.timestamp}</td>
                        <td>${log.ip_address}</td>
                        <td>${log.request_count}</td>
                        <td>${timeSinceLastRequest}</td>
                    </tr>`;
        });

        html += '</table>';
        res.send(html);
    });
});

// Dashboard route
app.get("/dashboard", isServerAuthenticated, (req, res) => {
    const tables = ['client_users', 'server_users', 'emergency_signals'];
    let data = {};

    function fetchTableData(index) {
        if (index >= tables.length) {
            res.render("dashboard", { data });
            return;
        }

        const table = tables[index];
        const query = `SELECT * FROM ${table}`;
        db.query(query, (err, results) => {
            if (err) throw err;
            data[table] = results;
            fetchTableData(index + 1);
        });
    }

    fetchTableData(0);
});

// Socket.io setup
let clients = {}; // Store client locations
let emergencies = {}; // Store emergency locations

io.on("connection", function (socket) {
    console.log("Client connected:", socket.id);

    // Send existing clients' locations and emergencies to the new client
    socket.emit("initialize", { clients, emergencies });

    // Map the socket ID to the user ID
    socket.on("register-user", (userId) => {
        clients[socket.id] = { userId };
    });

    // Handle incoming location data
    socket.on("send-location", function (data) {
        clients[socket.id] = { ...clients[socket.id], ...data };

        // Update emergency location if the user is in an emergency state
        if (emergencies[socket.id]) {
            emergencies[socket.id].latitude = data.latitude;
            emergencies[socket.id].longitude = data.longitude;
            io.emit("update-emergency-location", {
                id: socket.id,
                latitude: data.latitude,
                longitude: data.longitude,
                userId: emergencies[socket.id].userId,
                type: emergencies[socket.id].type,
                ipAddress: emergencies[socket.id].ipAddress,
                requestCount: emergencies[socket.id].requestCount,
                timestamp: new Date()
            });
        }

        io.emit("receive-location", { id: socket.id, ...data });
    });

    // Handle emergency button press
    socket.on("emergency", function (data) {
        console.log(`Emergency button pressed by ${socket.id}:`, data);

        // Get the client's IP address
        const ipAddress = socket.handshake.address;

        // Check if there is already an entry for this user and type
        const queryCheck = 'SELECT * FROM emergency_signals WHERE user_id = ? AND type = ? ORDER BY timestamp DESC LIMIT 1';
        db.query(queryCheck, [data.userId, data.type], (err, results) => {
            if (err) throw err;

            let requestCount = 1;
            if (results.length > 0) {
                requestCount = results[0].request_count + 1;
            }

            // Store the emergency signal in the database
            const queryInsert = 'INSERT INTO emergency_signals (user_id, latitude, longitude, type, ip_address, request_count) VALUES (?, ?, ?, ?, ?, ?)';
            db.query(queryInsert, [data.userId, data.latitude, data.longitude, data.type, ipAddress, requestCount], (err, result) => {
                if (err) throw err;
                console.log("Emergency signal stored in database");
            });

            emergencies[socket.id] = {
                latitude: data.latitude,
                longitude: data.longitude,
                userId: data.userId,
                type: data.type,
                ipAddress: ipAddress,
                requestCount: requestCount,
                timestamp: new Date()
            };
            io.emit("emergency-notification", {
                id: socket.id,
                latitude: data.latitude,
                longitude: data.longitude,
                userId: data.userId,
                type: data.type,
                ipAddress: ipAddress,
                requestCount: requestCount,
                timestamp: new Date()
            });
        });
    });

    // Handle client disconnection
    socket.on("disconnect", function () {
        console.log("Client disconnected:", socket.id);
        delete clients[socket.id];
        delete emergencies[socket.id];
        io.emit("client-disconnected", socket.id);
    });
});

// Listen on all network interfaces
server.listen(3030, '0.0.0.0', () => {
    console.log("Server is running on port 3030");
});